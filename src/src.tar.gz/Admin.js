import React, { Component } from 'react';
import './index.css';
import './Admin.css';
export default class Admin extends Component {
    render() {
        return (  
            <section class="admin" id="admin">
                        <div className = "admin_login">
                        
                        <div className = "header">XRECRUITS</div>
                        <div className = "username"><input className = "user" type='text' placeholder='Username'/></div>
                        <div className = "password"><input  className = "pass"type='text' placeholder='Password'/></div>
                        
                        <div className = "login" ><input class="btn btn-primary btn-xl bg-danger text-uppercase js-scroll-trigger" type='submit' value='Login' href="#login"/></div>
                        
                        </div>
                        
                    </section>
        )
    }
}